package com.harish.musicplayer;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.palette.graphics.Palette;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Random;

import static com.harish.musicplayer.AlbumDetailsActivtiy.albumSongs;
import static com.harish.musicplayer.AlbumDetailsAdapter.albumFiles;
import static com.harish.musicplayer.MainActivity.musicFiles;
import static com.harish.musicplayer.MainActivity.repeatBoolean;
import static com.harish.musicplayer.MainActivity.shffleBoolean;
import static com.harish.musicplayer.MusicAdapeter.mfiles;

public class PlayerActivity extends AppCompatActivity implements MediaPlayer.OnCompletionListener,ActionPlaying, ServiceConnection {
    TextView songName,artistName,duration_played,duration_total;
    ImageView cover_art,next_btn,pre_btn,back_btn,shuffle_btn,rep_btn;
    SeekBar seekBar;
    int position=-1;
    MusicService musicService;
    static MediaPlayer mediaPlayer;
    private Thread playThread,prevThread,nextThread;
    Uri uri;
    Handler handler=new Handler();
    FloatingActionButton playPause_btn;
    static ArrayList<MusicFiles>listSongs=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        initViews();
        getIntentMethod();
        mediaPlayer.setOnCompletionListener(this);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (mediaPlayer!=null && fromUser){
                    mediaPlayer.seekTo(progress*1000);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        PlayerActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer!=null){
                    int mCurrentPosistion=mediaPlayer.getCurrentPosition()/1000;
                    seekBar.setProgress(mCurrentPosistion);
                    duration_played.setText(formattedTime(mCurrentPosistion));
                }
                handler.postDelayed(this,1000);
            }
        });
        shuffle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (shffleBoolean){
                    shffleBoolean=false;
                    shuffle_btn.setImageResource(R.drawable.ic_shuffle_off);
                }else{
                    shffleBoolean=true;
                    shuffle_btn.setImageResource(R.drawable.ic_baseline_shuffle_24);
                }
            }
        });
        rep_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(repeatBoolean){
                    repeatBoolean=false;
                    rep_btn.setImageResource(R.drawable.ic_repeat_off);
                }else{
                    repeatBoolean=true;
                    rep_btn.setImageResource(R.drawable.ic_baseline_repeat_24);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        Intent intent=new Intent(this,MusicService.class);
        bindService(intent,this,BIND_AUTO_CREATE);
        playThreadBtn();
        nextThreadBtn();
        prevThreadBtn();
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unbindService(this);
    }

    private void prevThreadBtn(){
        prevThread=new Thread(){
            @Override
            public void run() {
                super.run();
                pre_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        preBtnClicked();
                    }
                });
            }
        };
        prevThread.start();
    }

    public void preBtnClicked() {
        if (mediaPlayer.isPlaying()){
            mediaPlayer.stop();
            mediaPlayer.release();
            if (shffleBoolean && !repeatBoolean){
                position=getRandom(listSongs.size()-1);
            }else if(!shffleBoolean && !repeatBoolean){
                position=(position-1) <0?(listSongs.size()-1):(position-1);
            }
            uri=Uri.parse(listSongs.get(position).getPath());
            mediaPlayer=MediaPlayer.create(getApplicationContext(),uri);
            metaData(uri);
            songName.setText(listSongs.get(position).getTitle());
            artistName.setText(listSongs.get(position).getArtist());

            seekBar.setMax(mediaPlayer.getDuration()/1000);

            PlayerActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mediaPlayer!=null){
                        int mCurrentPosistion=mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosistion);

                    }
                    handler.postDelayed(this,1000);
                }
            });
            mediaPlayer.setOnCompletionListener(this);
            playPause_btn.setBackgroundResource(R.drawable.ic_baseline_pause_24);
            mediaPlayer.start();
        }else{
            if (shffleBoolean && !repeatBoolean){
                position=getRandom(listSongs.size()-1);
            }else if(!shffleBoolean && !repeatBoolean){
                position=(position-1) <0?(listSongs.size()-1):(position-1);
            }
            uri=Uri.parse(listSongs.get(position).getPath());
            mediaPlayer=MediaPlayer.create(getApplicationContext(),uri);
            metaData(uri);
            songName.setText(listSongs.get(position).getTitle());
            artistName.setText(listSongs.get(position).getArtist());

            seekBar.setMax(mediaPlayer.getDuration()/1000);

            PlayerActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mediaPlayer!=null){
                        int mCurrentPosistion=mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosistion);

                    }
                    handler.postDelayed(this,1000);
                }
            });
            mediaPlayer.setOnCompletionListener(this);
            playPause_btn.setBackgroundResource(R.drawable.ic_baseline_play_arrow_24);
            mediaPlayer.start();
        }
    }

    public void playPauseBtnClicked() {
        if (mediaPlayer.isPlaying()){
            playPause_btn.setImageResource(R.drawable.ic_baseline_play_arrow_24);
            mediaPlayer.pause();
            seekBar.setMax(mediaPlayer.getDuration()/1000);

            PlayerActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mediaPlayer!=null){
                        int mCurrentPosistion=mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosistion);

                    }
                    handler.postDelayed(this,1000);
                }
            });
        }else{
            playPause_btn.setImageResource(R.drawable.ic_baseline_pause_24);
            mediaPlayer.start();
            seekBar.setMax(mediaPlayer.getDuration()/1000);
            PlayerActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mediaPlayer!=null){
                        int mCurrentPosistion=mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosistion);

                    }
                    handler.postDelayed(this,1000);
                }
            });
        }
    }

    public void nextBtnClicked() {
        if (mediaPlayer.isPlaying()){
            mediaPlayer.stop();
            mediaPlayer.release();
           if (shffleBoolean && !repeatBoolean){
               position=getRandom(listSongs.size()-1);
           }else if(!shffleBoolean && !repeatBoolean){
               position=(position +1) %listSongs.size();
           }
            //position=(position +1) %listSongs.size();
            uri=Uri.parse(listSongs.get(position).getPath());
            mediaPlayer=MediaPlayer.create(getApplicationContext(),uri);
            metaData(uri);
            songName.setText(listSongs.get(position).getTitle());
            artistName.setText(listSongs.get(position).getArtist());

            seekBar.setMax(mediaPlayer.getDuration()/1000);

            PlayerActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mediaPlayer!=null){
                        int mCurrentPosistion=mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosistion);

                    }
                    handler.postDelayed(this,1000);
                }
            });
            playPause_btn.setBackgroundResource(R.drawable.ic_baseline_pause_24);
            mediaPlayer.start();
        }else{
            mediaPlayer.stop();
            mediaPlayer.release();
            if (shffleBoolean && !repeatBoolean){
                position=getRandom(listSongs.size()-1);
            }else if(!shffleBoolean && !repeatBoolean){
                position=(position +1) %listSongs.size();
            }
            uri=Uri.parse(listSongs.get(position).getPath());
            mediaPlayer=MediaPlayer.create(getApplicationContext(),uri);
            metaData(uri);
            songName.setText(listSongs.get(position).getTitle());
            artistName.setText(listSongs.get(position).getArtist());

            seekBar.setMax(mediaPlayer.getDuration()/1000);

            PlayerActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mediaPlayer!=null){
                        int mCurrentPosistion=mediaPlayer.getCurrentPosition()/1000;
                        seekBar.setProgress(mCurrentPosistion);

                    }
                    handler.postDelayed(this,1000);
                }
            });
            mediaPlayer.setOnCompletionListener(this);
            playPause_btn.setBackgroundResource(R.drawable.ic_baseline_play_arrow_24);
            mediaPlayer.start();
        }
    }

    private int getRandom(int i) {
        Random random=new Random();
        return random.nextInt(i+2);
    }

    private void nextThreadBtn() {
        nextThread=new Thread(){
            @Override
            public void run() {
                super.run();
                next_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        nextBtnClicked();
                    }
                });
            }
        };
        nextThread.start();
    }

    private void playThreadBtn() {
        playThread=new Thread(){
            @Override
            public void run() {
                super.run();
                playPause_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        playPauseBtnClicked();
                    }
                });
            }
        };
        playThread.start();
    }

    private String formattedTime(int mCurrentPosistion) {
        String tottal_out="";
        String total_new="";
        String seconds=String.valueOf(mCurrentPosistion % 60);
        String minutes=String.valueOf(mCurrentPosistion/60);
        tottal_out=minutes+":"+seconds;
        total_new=minutes+":"+"0"+seconds;
        if (seconds.length()==1){
            return total_new;
        }else{
            return tottal_out;
        }
    }

    private void getIntentMethod() {
        position=getIntent().getIntExtra("position",-1);
        String sender=getIntent().getStringExtra("sender").toString();
        listSongs=musicFiles;
        if (sender!=null && sender.equals("albumDetails")){
            listSongs=albumFiles;
        }else{
            listSongs=mfiles;
        }
        if (listSongs!=null){
            playPause_btn.setImageResource(R.drawable.ic_baseline_pause_24);
            uri=Uri.parse(listSongs.get(position).getPath());

        }if (mediaPlayer!=null){
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer=MediaPlayer.create(getApplicationContext(),uri);
            mediaPlayer.start();
        }
        else{
            mediaPlayer=MediaPlayer.create(getApplicationContext(),uri);
            mediaPlayer.start();
        }
        seekBar.setMax(mediaPlayer.getDuration()/1000);
        artistName.setText(listSongs.get(position).getTitle());
        songName.setText(listSongs.get(position).getTitle());
        metaData(uri);
    }

    private void initViews() {
        songName=findViewById(R.id.song_name);
        artistName=findViewById(R.id.song_artist);
        duration_played=findViewById(R.id.duration_played);
        duration_total=findViewById(R.id.duration_Total);
        cover_art=findViewById(R.id.cover_art);
        next_btn=findViewById(R.id.next);
        pre_btn=findViewById(R.id.pre);
        back_btn=findViewById(R.id.back_btn);
        shuffle_btn=findViewById(R.id.shuffle);
        rep_btn=findViewById(R.id.repeate);
        seekBar=findViewById(R.id.seekBar);
        playPause_btn=findViewById(R.id.play_pause);
    }

    private void metaData(Uri uri){
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        retriever.setDataSource(uri.toString());
        int durationTotal=Integer.parseInt(listSongs.get(position).getDuration())/1000;
        duration_total.setText(formattedTime(durationTotal));

        byte[] art=retriever.getEmbeddedPicture();
        Bitmap bitmap;
        if (art!=null){
            bitmap= BitmapFactory.decodeByteArray(art,0,art.length);
            ImageAnimation(getApplicationContext(),cover_art,bitmap);
           Palette.from(bitmap).generate(new Palette.PaletteAsyncListener() {
               @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
               @Override
               public void onGenerated(@Nullable Palette palette) {
                   Palette.Swatch swatch=palette.getDominantSwatch();
                   if (swatch!=null){
                       ImageView gredient =findViewById(R.id.imageViewGradient);
                       RelativeLayout mContainer=findViewById(R.id.mcontainer);
                       gredient.setBackgroundResource(R.drawable.gradient_bg);
                       mContainer.setBackgroundResource(R.drawable.main_bg);

                       GradientDrawable gradientDrawable=new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{swatch.getRgb(),0x00000000});
                       gredient.setBackground(gradientDrawable);
                       GradientDrawable drawable=new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{swatch.getRgb(),swatch.getRgb()});
                       mContainer.setBackground(drawable);
                       songName.setTextColor(swatch.getTitleTextColor());
                       artistName.setTextColor(swatch.getBodyTextColor());
                   }
                   else{
                       ImageView gredient =findViewById(R.id.imageViewGradient);
                       RelativeLayout mContainer=findViewById(R.id.mcontainer);
                       gredient.setBackgroundResource(R.drawable.gradient_bg);
                       mContainer.setBackgroundResource(R.drawable.main_bg);

                       GradientDrawable gradientDrawable=new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{0xff000000,0x00000000});
                       gredient.setBackground(gradientDrawable);
                       GradientDrawable drawable=new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{0xff000000,0xff000000});
                       mContainer.setBackground(drawable);
                       songName.setTextColor(Color.WHITE);
                       artistName.setTextColor(Color.DKGRAY);
                   }
               }
           });
        }else{
            cover_art.setImageResource(R.drawable.music);
        }
    }    //set total duration and cover image

    private void ImageAnimation(final Context context, final ImageView imageView, final Bitmap bitmap){
        final Animation animIn=AnimationUtils.loadAnimation(context,android.R.anim.fade_in);
        Animation animOut=AnimationUtils.loadAnimation(context,android.R.anim.fade_out);

        animOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Glide.with(context).load(bitmap).into(imageView);
                animIn.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {

                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
                imageView.startAnimation(animIn);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        imageView.startAnimation(animOut);
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        nextBtnClicked();
        if (mediaPlayer!=null){

            mediaPlayer.setOnCompletionListener(this);
        }
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        MusicService.MyBinder myBinder=(MusicService.MyBinder)service;
        musicService=myBinder.getServices();
        Toast.makeText(this, "Connected "+musicService, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        musicService=null;
    }
}







