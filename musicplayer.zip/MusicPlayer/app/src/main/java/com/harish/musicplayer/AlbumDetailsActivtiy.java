package com.harish.musicplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.media.MediaMetadataRetriever;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import static com.harish.musicplayer.MainActivity.musicFiles;

public class AlbumDetailsActivtiy extends AppCompatActivity {
    ImageView albumPhoto;
    RecyclerView recyclerView;
    String albumName;
    AlbumDetailsAdapter albumDetailsAdapter;
   static ArrayList<MusicFiles>albumSongs=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_details_activtiy);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        albumSongs.clear();
        albumPhoto=findViewById(R.id.album_image1);
        recyclerView=findViewById(R.id.albumRecycler);
        albumName=getIntent().getStringExtra("albumFiles").toString();
        int j=0;
        for (int i=0;i<musicFiles.size();i++){
            if (albumName.equals(musicFiles.get(i).getAlbum())){
                albumSongs.add(j,musicFiles.get(i));
                j ++;
            }
        }
        byte[] image=getAlbunmArt(albumSongs.get(0).getPath());
            if (image!=null){
                Glide.with(this).load(image).into(albumPhoto);
            }else{
                Glide.with(this).load(R.drawable.music).into(albumPhoto);
            }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!(albumSongs.size() < 1)) {
            albumDetailsAdapter=new AlbumDetailsAdapter(this,albumSongs);
            recyclerView.setAdapter(albumDetailsAdapter);
        }
    }

    private byte[] getAlbunmArt(String uri) {
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        retriever.setDataSource(uri);
        byte[]  art=retriever.getEmbeddedPicture();
        retriever.release();
        return art;
    }
}