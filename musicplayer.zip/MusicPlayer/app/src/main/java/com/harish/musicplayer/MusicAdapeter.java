package com.harish.musicplayer;

import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.util.ArrayList;

public class MusicAdapeter extends RecyclerView.Adapter<MusicAdapeter.ViewHolder>  {
    Context context;
   static ArrayList<MusicFiles>mfiles;

    public MusicAdapeter(Context context, ArrayList<MusicFiles> musicFiles) {
        this.context = context;
        this.mfiles = musicFiles;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.music_items,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.file_name.setText(mfiles.get(position).getTitle());
        byte[] image=getAlbumArt(mfiles.get(position).getPath());

        if (image!=null){
            Glide.with(context).asBitmap().load(image).into(holder.album_art);
        }else{
            Glide.with(context).load(R.drawable.music).into(holder.album_art);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent=new Intent(context,PlayerActivity.class);
               intent.putExtra("position",position);
               intent.putExtra("sender","");
               context.startActivity(intent);
            }
        });

        holder.more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {

                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setItems(new String[]{"Delete"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which==0){
                           deleteFile(position,v);
                        }
                        else{
                        }
                    }
                });
                builder.create().show();
            }
        });
    }

    private void deleteFile(int position ,View view){
        Uri contentUri=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,Long.parseLong(mfiles.get(position).getId()));
        File file=new File(mfiles.get(position).getPath());
        boolean deleted=file.delete();
        if (deleted){
            context.getContentResolver().delete(contentUri,null,null);
            mfiles.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position,mfiles.size());
            Snackbar.make(view,"Deleted",Snackbar.LENGTH_LONG).show();
        }else{
            Snackbar.make(view,"can't Delete", Snackbar.LENGTH_LONG).show();
        }
    }

    @Override
    public int getItemCount() {
        return mfiles.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView album_art,more;
        TextView file_name;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            album_art=itemView.findViewById(R.id.music_img);
            file_name=itemView.findViewById(R.id.music_filename);
            more=itemView.findViewById(R.id.more1);
        }
    }

    private byte[] getAlbumArt(String uri){
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        retriever.setDataSource(uri);
        byte[] art=retriever.getEmbeddedPicture();
        retriever.release();
        return  art;
    }

    void updateList(ArrayList<MusicFiles>musicFileArrayList){
        mfiles=new ArrayList<>();
        mfiles.addAll(musicFileArrayList);
        notifyDataSetChanged();
    }
}
