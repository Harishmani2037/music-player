package com.harish.musicplayer;

public interface ActionPlaying {
    void preBtnClicked();
    void nextBtnClicked();
    void playPauseBtnClicked();
}
