package com.harish.musicplayer;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class ApplicationClass extends Application {
    private static final String CHANNEL_ID_1="channelId1";
    private static final String CHANNEL_ID_2="channelId2";
    private static final String Action_Previos="actionPrevious";
    private static final String Action_Next="actionNext";
    private static final String Action_Play="actionPlay";
    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    public void createNotificationChannel(){
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel notificationChannel1=new NotificationChannel(CHANNEL_ID_1,"channel(1)", NotificationManager.IMPORTANCE_HIGH);
            notificationChannel1.setDescription("Channel 1 Desc ...");
            NotificationChannel notificationChannel2=new NotificationChannel(CHANNEL_ID_2,"cahnnel(2)",NotificationManager.IMPORTANCE_HIGH);
            notificationChannel2.setDescription("Channel 2 Desc ...");
            NotificationManager notificationManager=getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(notificationChannel1);
            notificationManager.createNotificationChannel(notificationChannel2);
        }
    }
}
